const a="/assets/banner_reklama-0925924d.png",s="https://example.com/";export{s as B,a as b};
